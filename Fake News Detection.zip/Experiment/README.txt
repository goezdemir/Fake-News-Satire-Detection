-Im Ornder 'Datensätze' befinden sich der Trainings- und Testdatensatz. Für diese muss eventuell der Datenpfad im Quellcode angepasst werden. Ansonsten reicht auch,
nur den Dateinamen anzugeben und die Datensätze im selben Ordner wie die Notebooks zu speichern.
-Im Ornder 'Notebooks' befinden sich drei Notebooks. In jedem dieser Notebooks wurde mit einem anderem Modell experimentiert.
-Im Ordner 'Notebooks HTML' befinden sich drei HTML-Dateien, die ausgeführte Versionen der Notebooks darstellen. In diesen wurden die jeweils
performantesten Modelle, welche letztendlich auch in der Arbeit aufgeführt werden, ausgeführt.
-Die Jupyter Notebooks wurden mit Python Version 3.9.7 erstellt.